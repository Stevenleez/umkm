package Case2;

import java.util.*;

class Comment {
    int commentId;
    String commentContent;
    List<Comment> replies;

    public Comment(int commentId, String commentContent, List<Comment> replies) {
        this.commentId = commentId;
        this.commentContent = commentContent;
        this.replies = replies != null ? replies : new ArrayList<>();
    }
}

public class Main {
    public static int countComments(List<Comment> comments) {
        if (comments == null) {
            return 0;
        }

        int count = comments.size();
        for(Comment comment: comments) {
            count += countComments(comment.replies);
        }

        return count;
    }

    public static void main(String[] args) {
        List<Comment> comments = Arrays.asList(
            new Comment(
                1,
                "Hai",
                Arrays.asList(
                    new Comment(
                        11,
                        "Hai juga",
                        Arrays.asList(
                            new Comment(
                                111,
                                "Haai juga hai jugaa", null),
                            new Comment(
                                112,
                                "Haai juga hai jugaa", null)
                    )),
                    new Comment(
                        12,
                        "Hai juga",
                        Arrays.asList(
                            new Comment(
                                121,
                                "Haai juga hai jugaa", null)
                    ))
                )),
            new Comment(2, "Halooo", null)
            );

        // Total komentar?
        int totalComments = countComments(comments);
        System.out.println("Total Komentar: " + totalComments);
    }
}
