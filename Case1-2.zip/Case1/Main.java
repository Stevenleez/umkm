package Case1;

import java.util.*;
import java.util.stream.Collectors;

class Fruit {
    int fruitId;
    String fruitName;
    String fruitType;
    int stock;

    public Fruit(int fruitId, String fruitName, String fruitType, int stock) {
        this.fruitId = fruitId;
        this.fruitName = fruitName;
        this.fruitType = fruitType;
        this.stock = stock;
    }
}

public class Main {
    public static void main(String[] args) {
        List<Fruit> fruits = Arrays.asList(
            new Fruit(1, "Apel", "IMPORT", 10),
            new Fruit(2, "Kurma", "IMPORT", 20),
            new Fruit(3, "apel", "IMPORT", 50),
            new Fruit(4, "Manggis", "LOCAL", 100),
            new Fruit(5, "Jeruk Bali", "LOCAL", 10),
            new Fruit(5, "KURMA", "IMPORT", 20),
            new Fruit(5, "Salak", "LOCAL", 150)
        );

        // 1. Buah apa saja yang dimiliki Andi?
        Set<String> fruitNames = fruits.stream()
                .map(fruit -> fruit.fruitName.toLowerCase())
                .collect(Collectors.toSet());
        System.out.println("1. Buah yang dimiliki Andi: " + fruitNames);

        // 2. Berapa jumlah wadah yang dibutuhkan? Dan ada buah apa saja di masing-masing wadah?
        Map<String, List<String>> fruitTypes = fruits.stream()
                .collect(Collectors.groupingBy(fruit -> fruit.fruitType,
                        Collectors.mapping(fruit -> fruit.fruitName, Collectors.toList())));
        System.out.println("2.\n a. Jumlah wadah yang dibutuhkan: " + fruitTypes.size() +
                "\n b. Jumlah wadah yang dibutuhkan dan isinya: " + fruitTypes);

        // 3. Berapa total stock buah yang ada di masing-masing wadah?
        Map<String, Integer> typeStocks = fruits.stream().
                collect(Collectors.groupingBy(fruit -> fruit.fruitType,
                        Collectors.summingInt(fruit ->fruit.stock)));
        System.out.println("3. Total stock buah yang ada di masing-masing wadah: " + typeStocks);

        // 4. Apakah ada komentar terkait kasus di atas?
        System.out.println("4. Komentar: Ada beberapa buah yang memiliki ID duplikat ");
    }
}